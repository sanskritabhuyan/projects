<?php
// pages/admin/dashboard.php - Admin Dashboard
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

$pageTitle = 'Admin Dashboard';

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $stats = [
        'users' => $conn->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'user'")->fetch_assoc()['count'],
        'providers' => $conn->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'provider'")->fetch_assoc()['count'],
        'bookings' => $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'],
        'pending_bookings' => $conn->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'")->fetch_assoc()['count'],
    ];
} catch (Exception $e) {
    error_log("Admin dashboard error: " . $e->getMessage());
    $stats = ['users' => 0, 'providers' => 0, 'bookings' => 0, 'pending_bookings' => 0];
}

include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    .dashboard-section {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: calc(100vh - 56px);
        padding: 3rem 0;
    }
    .dashboard-card {
        background: rgba(30, 41, 59, 0.3);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease;
    }
    .dashboard-card:hover {
        transform: scale(1.02);
    }
    .stat-card {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        border-radius: 8px;
        padding: 1.5rem;
        text-align: center;
        transition: transform 0.3s ease;
    }
    .stat-card:hover {
        transform: scale(1.05);
    }
    .btn-gold {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        transition: transform 0.3s ease, background 0.3s ease;
    }
    .btn-gold:hover {
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
        transform: scale(1.05);
    }
    .text-gold {
        color: #facc15;
    }
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    @media (max-width: 576px) {
        .dashboard-card {
            padding: 1.5rem;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Dashboard Section -->
<section class="dashboard-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Admin Dashboard</h2>
        <div class="dashboard-card">
            <h3 class="h4 fw-bold text-light mb-4">System Overview</h3>
            <div class="row g-4">
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card">
                        <h5 class="text-gold mb-2">Users</h5>
                        <p class="h3 text-light mb-0"><?php echo $stats['users']; ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card">
                        <h5 class="text-gold mb-2">Providers</h5>
                        <p class="h3 text-light mb-0"><?php echo $stats['providers']; ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card">
                        <h5 class="text-gold mb-2">Total Bookings</h5>
                        <p class="h3 text-light mb-0"><?php echo $stats['bookings']; ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="stat-card">
                        <h5 class="text-gold mb-2">Pending Bookings</h5>
                        <p class="h3 text-light mb-0"><?php echo $stats['pending_bookings']; ?></p>
                    </div>
                </div>
            </div>
            <div class="mt-4">
                <a href="<?php echo APP_URL; ?>/pages/admin/manage_users.php" class="btn btn-gold me-2">Manage Users</a>
                <a href="<?php echo APP_URL; ?>/pages/admin/manage_providers.php" class="btn btn-gold">Manage Providers</a>
            </div>
        </div>
    </div>
</section>

<?php include '../../includes/footer.php'; ?>

<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });
        sections.forEach(section => observer.observe(section));
    });
</script>

<?php
if (isset($db)) {
    $db->closeConnection();
}
?>