<?php
// pages/admin/manage_users.php - Admin User Management
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

$errors = [];
$success = '';

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $stmt = $conn->query("SELECT user_id, full_name, email, user_type FROM users ORDER BY user_id");
    $users = $stmt->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    error_log("Manage users error: " . $e->getMessage());
    $errors[] = 'Unable to load users.';
    $users = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['action'])) {
    $user_id = intval($_POST['user_id']);
    $action = $_POST['action'];

    if ($action === 'delete' && $user_id !== $_SESSION['user_id']) {
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare("DELETE FROM service_providers WHERE user_id = ?");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM bookings WHERE user_id = ? OR provider_id IN (SELECT provider_id FROM service_providers WHERE user_id = ?)");
            $stmt->bind_param('ii', $user_id, $user_id);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $success = 'User deleted successfully.';
            header('Location: ' . APP_URL . '/pages/admin/manage_users.php');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            error_log("User deletion error: " . $e->getMessage());
            $errors[] = 'An error occurred. Please try again.';
        }
    } else {
        $errors[] = 'Invalid action or cannot delete own account.';
    }
}

$pageTitle = 'Manage Users';
include '../../includes/header