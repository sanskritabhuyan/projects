<?php
// pages/user/booking.php - User Booking Management
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'user') {
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

$errors = [];
$success = '';
$service_type = '';
$booking_date = '';

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $stmt = $conn->prepare("SELECT sp.provider_id, u.full_name, sp.service_type 
                            FROM service_providers sp 
                            JOIN users u ON sp.user_id = u.user_id 
                            WHERE sp.availability_status = 1");
    $stmt->execute();
    $result = $stmt->get_result();
    $providers = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $stmt = $conn->prepare("SELECT b.booking_id, b.service_type, b.booking_date, b.status, u.full_name 
                            FROM bookings b 
                            JOIN service_providers sp ON b.provider_id = sp.provider_id 
                            JOIN users u ON sp.user_id = u.user_id 
                            WHERE b.user_id = ? 
                            ORDER BY b.created_at DESC");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (Exception $e) {
    error_log("Booking fetch error: " . $e->getMessage());
    $errors[] = 'Unable to load data.';
    $providers = [];
    $bookings = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $provider_id = trim($_POST['provider_id'] ?? '');
    $service_type = trim($_POST['service_type'] ?? '');
    $booking_date = trim($_POST['booking_date'] ?? '');

    if (empty($provider_id)) {
        $errors[] = 'Please select a provider.';
    }
    if (empty($service_type)) {
        $errors[] = 'Service type is required.';
    }
    if (empty($booking_date) || strtotime($booking_date) < time()) {
        $errors[] = 'Valid future booking date is required.';
    }

    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("INSERT INTO bookings (user_id, provider_id, service_type, booking_date, status) 
                                    VALUES (?, ?, ?, ?, 'pending')");
            $stmt->bind_param('iiss', $_SESSION['user_id'], $provider_id, $service_type, $booking_date);
            $stmt->execute();
            $stmt->close();
            $success = 'Booking created successfully.';
            header('Location: ' . APP_URL . '/pages/user/booking.php');
            exit;
        } catch (Exception $e) {
            error_log("Booking creation error: " . $e->getMessage());
            $errors[] = 'An error occurred. Please try again.';
        }
    }
}

$pageTitle = 'Book a Service';
include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    .booking-section {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: calc(100vh - 56px);
        padding: 3rem 0;
    }
    .booking-container, .history-container {
        background: rgba(30, 41, 59, 0.3);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease;
    }
    .booking-container:hover, .history-container:hover {
        transform: scale(1.02);
    }
    .form-control, .form-select {
        background: rgba(30, 41, 59, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #f3f4f6;
    }
    .form-control:focus, .form-select:focus {
        background: rgba(30, 41, 59, 0.7);
        border-color: #facc15;
        box-shadow: none;
    }
    .form-label {
        color: #facc15;
    }
    .btn-gold {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        transition: transform 0.3s ease, background 0.3s ease;
    }
    .btn-gold:hover {
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
        transform: scale(1.05);
    }
    .table {
        background: rgba(30, 41, 59, 0.5);
        color: #f3f4f6;
    }
    .table th, .table td {
        border-color: rgba(255, 255, 255, 0.1);
    }
    .error-message, .success-message {
        background: rgba(254, 226, 226, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #facc15;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }
    .success-message {
        background: rgba(209, 250, 229, 0.2);
    }
    .text-gold {
        color: #facc15;
    }
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    @media (max-width: 576px) {
        .booking-container, .history-container {
            padding: 1.5rem;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Booking Section -->
<section class="booking-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Book a Service</h2>
        <div class="booking-container mx-auto mb-5" style="max-width: 500px;">
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <?php foreach ($errors as $error): ?>
                        <p class="mb-0"><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success-message">
                    <p class="mb-0"><?php echo htmlspecialchars($success); ?></p>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="mb-3">
                    <label for="provider_id" class="form-label"><i class="fas fa-users me-2"></i>Select Provider</label>
                    <select class="form-select" id="provider_id" name="provider_id" required>
                        <option value="">Choose a provider</option>
                        <?php foreach ($providers as $provider): ?>
                            <option value="<?php echo $provider['provider_id']; ?>">
                                <?php echo htmlspecialchars($provider['full_name'] . ' (' . $provider['service_type'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="service_type" class="form-label"><i class="fas fa-tools me-2"></i>Service Type</label>
                    <input type="text" class="form-control" id="service_type" name="service_type" value="<?php echo htmlspecialchars($service_type); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="booking_date" class="form-label"><i class="fas fa-calendar me-2"></i>Booking Date</label>
                    <input type="datetime-local" class="form-control" id="booking_date" name="booking_date" value="<?php echo htmlspecialchars($booking_date); ?>" required>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-gold">Create Booking</button>
                </div>
            </form>
        </div>
        <div class="history-container">
            <h3 class="h4 fw-bold text-light mb-4">Booking History</h3>
            <?php if (empty($bookings)): ?>
                <p class="text-light">No bookings yet.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Provider</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($booking['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                    <td><?php echo htmlspecialchars(date('Y-m-d H:i', strtotime($booking['booking_date']))); ?></td>
                                    <td><?php echo htmlspecialchars(ucfirst($booking['status'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include '../../includes/footer.php'; ?>

<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });
        sections.forEach(section => observer.observe(section));
    });
</script>

<?php
if (isset($db)) {
    $db->closeConnection();
}
?>