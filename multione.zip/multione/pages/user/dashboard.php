<?php
// pages/user/dashboard.php - User Dashboard
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in or not a regular user
if (!isset($_SESSION['user_id']) || (isset($_SESSION['is_provider']) && $_SESSION['is_provider']) || (isset($_SESSION['is_admin']) && $_SESSION['is_admin'])) {
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

$pageTitle = 'User Dashboard';

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $stmt = $conn->prepare("SELECT booking_id, service_type, booking_date, status 
                            FROM bookings 
                            WHERE user_id = ? 
                            ORDER BY created_at DESC 
                            LIMIT 5");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (Exception $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $bookings = [];
} finally {
    if (isset($db)) {
        $db->closeConnection();
    }
}

include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    .dashboard-section {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: calc(100vh - 56px);
        padding: 3rem 0;
    }
    .dashboard-card {
        background: rgba(30, 41, 59, 0.3);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease;
    }
    .dashboard-card:hover {
        transform: scale(1.02);
    }
    .table {
        background: rgba(30, 41, 59, 0.5);
        color: #f3f4f6;
    }
    .table th, .table td {
        border-color: rgba(255, 255, 255, 0.1);
    }
    .btn-gold {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        transition: transform 0.3s ease, background 0.3s ease;
    }
    .btn-gold:hover {
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
        transform: scale(1.05);
    }
    .text-gold {
        color: #facc15;
    }
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    @media (max-width: 576px) {
        .dashboard-card {
            padding: 1.5rem;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Dashboard Section -->
<section class="dashboard-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h2>
        <div class="dashboard-card">
            <h3 class="h4 fw-bold text-light mb-4">Recent Bookings</h3>
            <?php if (empty($bookings)): ?>
                <p class="text-light">No bookings yet. <a href="<?php echo APP_URL; ?>/pages/user/booking.php" class="text-gold">Book a service now</a>.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                    <td><?php echo htmlspecialchars(date('Y-m-d H:i', strtotime($booking['booking_date']))); ?></td>
                                    <td><?php echo htmlspecialchars(ucfirst($booking['status'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            <a href="<?php echo APP_URL; ?>/pages/user/booking.php" class="btn btn-gold mt-3">Book a Service</a>
        </div>
    </div>
</section>

<?php include '../../includes/footer.php'; ?>

<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });
        sections.forEach(section => observer.observe(section));
    });
</script>

<?php
if (isset($db)) {
    $db->closeConnection();
}
?>