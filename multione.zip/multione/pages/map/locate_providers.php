<?php
// locate_providers.php - Provider Location Map Page
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check login status
$isLoggedIn = isset($_SESSION['user_id']);
$userType = isset($_SESSION['user_type']) ? $_SESSION['user_type'] : null;

// Set page title
$pageTitle = 'Locate Providers';

// Include header
include __DIR__ . '/../../includes/header.php';
?>

<!-- Custom CSS (matches index.php styles) -->
<style>
    /* Map Section - Extended from index.php */
    .map-section {
        background: #0f172a;
        padding: 4rem 0;
    }
    .map-container {
        height: 600px;
        width: 100%;
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        position: relative;
        z-index: 1;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .map-container:hover {
        transform: scale(1.01);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
    }
    .map-container .leaflet-container {
        background: transparent;
    }
    .custom-marker {
        font-size: 20px;
        color: #facc15;
    }
    .marker-pin {
        color: #facc15;
        font-size: 24px;
        text-align: center;
    }
    .error-message {
        background: rgba(254, 226, 226, 0.2);
        padding: 1.5rem;
        border-radius: 8px;
        text-align: center;
        margin-bottom: 2rem;
        color: #f3f4f6;
    }
    
    /* Filter Controls */
    .filter-container {
        background: rgba(15, 23, 42, 0.8);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 8px;
        padding: 1.5rem;
        margin-bottom: 2rem;
    }
    .filter-title {
        color: #facc15;
        margin-bottom: 1rem;
    }
    .filter-btn {
        background: rgba(250, 204, 21, 0.1);
        border: 1px solid rgba(250, 204, 21, 0.3);
        color: #facc15;
        transition: all 0.3s ease;
    }
    .filter-btn:hover, .filter-btn.active {
        background: rgba(250, 204, 21, 0.3);
        color: white;
    }
    
    /* Provider Info Panel */
    .provider-panel {
        background: rgba(15, 23, 42, 0.8);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 8px;
        padding: 1.5rem;
        margin-top: 2rem;
    }
    .provider-card {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
    }
    .provider-card:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: translateY(-3px);
    }
    .provider-name {
        color: #facc15;
        font-weight: 600;
    }
    .provider-service {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    .electrician-badge {
        background: rgba(234, 179, 8, 0.2);
        color: #facc15;
    }
    .plumber-badge {
        background: rgba(59, 130, 246, 0.2);
        color: #3b82f6;
    }
    .carpenter-badge {
        background: rgba(139, 92, 246, 0.2);
        color: #8b5cf6;
    }
    
    /* Animation Classes (from index.php) */
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-map {
        opacity: 0;
        transform: scale(0.95);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-map {
        opacity: 1;
        transform: scale(1);
    }
    
    @media (max-width: 768px) {
        .map-container {
            height: 400px;
        }
    }
</style>

<!-- Main Content -->
<section class="map-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Locate Service Providers</h2>
        
        <!-- Filter Controls -->
        <div class="filter-container animate-section" data-animate>
            <h3 class="filter-title animate-title">Filter by Service</h3>
            <div class="d-flex flex-wrap gap-2 animate-text">
                <button class="btn filter-btn active" data-service="all">All Services</button>
                <button class="btn filter-btn" data-service="electrician">
                    <i class="fas fa-bolt me-2"></i> Electricians
                </button>
                <button class="btn filter-btn" data-service="plumber">
                    <i class="fas fa-faucet me-2"></i> Plumbers
                </button>
                <button class="btn filter-btn" data-service="carpenter">
                    <i class="fas fa-hammer me-2"></i> Carpenters
                </button>
            </div>
        </div>
        
        <div id="map-error" class="error-message" style="display: none;"></div>
        <div id="map" class="map-container glassmorphic animate-map"></div>
        
        <!-- Provider List Panel -->
        <div class="provider-panel animate-section" data-animate>
            <h3 class="filter-title animate-title">Available Providers</h3>
            <div id="provider-list" class="animate-text">
                <!-- Provider cards will be loaded here via JavaScript -->
                <div class="text-center py-4">
                    <div class="spinner-border text-gold" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 text-light">Loading providers...</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Include footer -->
<?php include __DIR__ . '/../../includes/footer.php'; ?>

<!-- Scripts -->
<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo ASSETS_PATH; ?>/js/leaflet.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Animation Script (same as index.php)
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    if (entry.target.classList.contains('map-section')) {
                        initializeMap();
                    }
                }
            });
        }, { threshold: 0.1 });

        sections.forEach(section => observer.observe(section));

        // Map and Provider Data
        let map;
        let markers = [];
        let allProviders = [];
        
        // Initialize Map
        function initializeMap() {
            try {
                const mapContainer = document.getElementById('map');
                const errorDiv = document.getElementById('map-error');
                
                // Create map instance
                map = L.map('map', {
                    center: [26.1445, 91.7362], // Guwahati, Assam
                    zoom: 13,
                    scrollWheelZoom: true
                });

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                    maxZoom: 18
                }).addTo(map);

                // Custom marker icon
                const customIcon = L.divIcon({
                    className: 'custom-marker',
                    html: '<div class="marker-pin"><i class="fas fa-map-pin"></i></div>',
                    iconSize: [40, 40],
                    iconAnchor: [20, 40],
                    popupAnchor: [0, -40]
                });

                // Load provider data
                loadProviders();
                
                // Handle window resize
                setTimeout(() => map.invalidateSize(), 500);
                window.addEventListener('resize', () => map.invalidateSize());
            } catch (e) {
                console.error('Map initialization failed:', e);
                document.getElementById('map-error').textContent = 'Failed to initialize map.';
                document.getElementById('map-error').style.display = 'block';
            }
        }
        
        // Load providers from API
        function loadProviders() {
            fetch('<?php echo APP_URL; ?>/api/providers.php')
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP error ${response.status}`);
                    return response.json();
                })
                .then(data => {
                    allProviders = data;
                    updateProvidersDisplay('all');
                })
                .catch(error => {
                    console.error('Error loading providers:', error);
                    document.getElementById('map-error').textContent = 'Error loading providers. Please try again later.';
                    document.getElementById('map-error').style.display = 'block';
                    
                    // Show empty state in provider list
                    document.getElementById('provider-list').innerHTML = `
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Unable to load providers. Please try again later.
                        </div>
                    `;
                });
        }
        
        // Update displayed providers based on filter
        function updateProvidersDisplay(serviceType) {
            const filteredProviders = serviceType === 'all' 
                ? allProviders 
                : allProviders.filter(p => p.service_type === serviceType);
            
            // Clear existing markers
            markers.forEach(marker => map.removeLayer(marker));
            markers = [];
            
            // Update map markers
            const bounds = [];
            filteredProviders.forEach(provider => {
                if (provider.location_lat && provider.location_lng) {
                    const latLng = [provider.location_lat, provider.location_lng];
                    bounds.push(latLng);
                    
                    const marker = L.marker(latLng, { 
                        icon: L.divIcon({
                            className: 'custom-marker',
                            html: `<div class="marker-pin"><i class="fas fa-${getServiceIcon(provider.service_type)}"></i></div>`,
                            iconSize: [40, 40],
                            iconAnchor: [20, 40],
                            popupAnchor: [0, -40]
                        })
                    }).addTo(map);
                    
                    marker.bindPopup(`
                        <div class="map-popup">
                            <h5 class="provider-name">${provider.full_name}</h5>
                            <span class="provider-service ${provider.service_type}-badge">
                                ${provider.service_type.charAt(0).toUpperCase() + provider.service_type.slice(1)}
                            </span>
                            <p class="mb-1"><i class="fas fa-phone me-2"></i> ${provider.phone || 'Not provided'}</p>
                            ${provider.address ? `<p class="mb-0"><i class="fas fa-map-marker-alt me-2"></i> ${provider.address.substring(0, 50)}...</p>` : ''}
                        </div>
                    `);
                    
                    markers.push(marker);
                }
            });
            
            // Fit map to bounds if we have markers
            if (bounds.length > 0) {
                map.fitBounds(bounds, { padding: [50, 50] });
            } else {
                // Default to Guwahati if no providers
                map.setView([26.1445, 91.7362], 13);
            }
            
            // Update provider list
            updateProviderList(filteredProviders);
        }
        
        // Update the provider list HTML
        function updateProviderList(providers) {
            const providerList = document.getElementById('provider-list');
            
            if (providers.length === 0) {
                providerList.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        No providers found for the selected service type.
                    </div>
                `;
                return;
            }
            
            providerList.innerHTML = providers.map(provider => `
                <div class="provider-card" data-id="${provider.provider_id}" data-lat="${provider.location_lat}" data-lng="${provider.location_lng}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h4 class="provider-name mb-1">${provider.full_name}</h4>
                            <span class="provider-service ${provider.service_type}-badge">
                                <i class="fas fa-${getServiceIcon(provider.service_type)} me-2"></i>
                                ${provider.service_type.charAt(0).toUpperCase() + provider.service_type.slice(1)}
                            </span>
                        </div>
                        <button class="btn btn-sm btn-outline-gold view-on-map" data-id="${provider.provider_id}">
                            <i class="fas fa-map-marked-alt"></i>
                        </button>
                    </div>
                    ${provider.phone ? `<p class="mb-1 mt-2"><i class="fas fa-phone me-2"></i> ${provider.phone}</p>` : ''}
                    ${provider.address ? `<p class="mb-0 text-truncate"><i class="fas fa-map-marker-alt me-2"></i> ${provider.address}</p>` : ''}
                </div>
            `).join('');
            
            // Add click handlers for "View on Map" buttons
            document.querySelectorAll('.view-on-map').forEach(button => {
                button.addEventListener('click', (e) => {
                    const providerId = e.target.closest('button').getAttribute('data-id');
                    const providerCard = document.querySelector(`.provider-card[data-id="${providerId}"]`);
                    const lat = providerCard.getAttribute('data-lat');
                    const lng = providerCard.getAttribute('data-lng');
                    
                    if (lat && lng) {
                        map.setView([lat, lng], 15);
                        
                        // Highlight the marker
                        const providerMarker = markers.find(m => 
                            m.getLatLng().lat == lat && 
                            m.getLatLng().lng == lng
                        );
                        
                        if (providerMarker) {
                            providerMarker.openPopup();
                            providerMarker.setIcon(L.divIcon({
                                className: 'custom-marker highlighted',
                                html: '<div class="marker-pin"><i class="fas fa-map-marker-alt"></i></div>',
                                iconSize: [50, 50],
                                iconAnchor: [25, 50],
                                popupAnchor: [0, -50]
                            }));
                            
                            // Reset after 3 seconds
                            setTimeout(() => {
                                providerMarker.setIcon(L.divIcon({
                                    className: 'custom-marker',
                                    html: `<div class="marker-pin"><i class="fas fa-${getServiceIcon(providerMarker.provider?.service_type || 'electrician')}"></i></div>`,
                                    iconSize: [40, 40],
                                    iconAnchor: [20, 40],
                                    popupAnchor: [0, -40]
                                }));
                            }, 3000);
                        }
                    }
                });
            });
        }
        
        // Get appropriate icon for service type
        function getServiceIcon(serviceType) {
            switch(serviceType) {
                case 'electrician': return 'bolt';
                case 'plumber': return 'faucet';
                case 'carpenter': return 'hammer';
                default: return 'user';
            }
        }
        
        // Filter button click handlers
        document.querySelectorAll('.filter-btn').forEach(button => {
            button.addEventListener('click', () => {
                document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                const serviceType = button.getAttribute('data-service');
                updateProvidersDisplay(serviceType);
            });
        });
    });
</script>

<?php
// Close database connection
if (isset($db)) {
    $db->closeConnection();
}
?>