<?php
// login.php - MULTIONE Login Page
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['is_provider']) && $_SESSION['is_provider']) {
        header('Location: ' . APP_URL . '/pages/provider/dashboard.php');
    } elseif (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) {
        header('Location: ' . APP_URL . '/pages/admin/dashboard.php');
    } else {
        header('Location: ' . APP_URL . '/pages/user/dashboard.php');
    }
    exit;
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Log POST data for debugging
    error_log("POST data: " . print_r($_POST, true));

    // Validate input
    if (empty($email)) {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format.';
    }
    if (empty($password)) {
        $errors[] = 'Password is required.';
    }

    if (empty($errors)) {
        try {
            $db = Database::getInstance();
            $conn = $db->getConnection();

            // Verify database connection
            if (!$conn) {
                throw new Exception("Database connection failed: " . mysqli_connect_error());
            }

            // Check users table
            $stmt = $conn->prepare("SELECT user_id, username, password FROM users WHERE email = ?");
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['is_admin'] = false;

                    // Check if user is a provider
                    $provider_stmt = $conn->prepare("SELECT provider_id FROM service_providers WHERE user_id = ?");
                    if (!$provider_stmt) {
                        throw new Exception("Prepare failed: " . $conn->error);
                    }
                    $provider_stmt->bind_param('i', $user['user_id']);
                    $provider_stmt->execute();
                    $provider_result = $provider_stmt->get_result();
                    $_SESSION['is_provider'] = ($provider_result->num_rows > 0);
                    $provider_stmt->close();

                    // Redirect based on role
                    header('Location: ' . APP_URL . ($_SESSION['is_provider'] ? '/pages/provider/dashboard.php' : '/pages/user/dashboard.php'));
                    exit;
                } else {
                    $errors[] = 'Incorrect password.';
                }
            }
            $stmt->close();

            // Check admins table
            $stmt = $conn->prepare("SELECT admin_id, username, password FROM admins WHERE email = ?");
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 1) {
                $admin = $result->fetch_assoc();
                if (password_verify($password, $admin['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $admin['admin_id'];
                    $_SESSION['username'] = $admin['username'];
                    $_SESSION['is_admin'] = true;
                    $_SESSION['is_provider'] = false;
                    header('Location: ' . APP_URL . '/pages/admin/dashboard.php');
                    exit;
                } else {
                    $errors[] = 'Incorrect password.';
                }
            }
            $stmt->close();

            $errors[] = 'No account found with that email.';
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            $errors[] = 'An error occurred: ' . htmlspecialchars($e->getMessage());
        } finally {
            if (isset($db)) {
                $db->closeConnection();
            }
        }
    }
}

// Set page title
$pageTitle = 'Login';

// Include header
include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    /* Login Section */
    .login-section {
        background: linear-gradient(135deg, #1e3a8a, #60a5fa);
        min-height: calc(100vh - 56px);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem 0;
    }
    .login-container {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        width: 100%;
        max-width: 400px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease;
    }
    .login-container:hover {
        transform: scale(1.02);
    }
    .form-control {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #f3f4f6;
        transition: border-color 0.3s ease;
    }
    .form-control:focus {
        background: rgba(255, 255, 255, 0.1);
        border-color: #facc15;
        color: #f3f4f6;
        box-shadow: none;
    }
    .form-label {
        color: #facc15;
        font-weight: 500;
    }
    .login-button {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        font-weight: 500;
        padding: 0.75rem;
        transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
    }
    .login-button:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
    }
    .error-message {
        background: rgba(254, 226, 226, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #facc15;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }
    .text-gold {
        color: #facc15;
    }
    /* Typing Animation */
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }
    /* Animation Classes */
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-form {
        opacity: 0;
        transform: scale(0.95);
        transition: opacity 0.8s ease, transform 0.8s ease 0.4s;
    }
    .animate-section.visible .animate-form {
        opacity: 1;
        transform: scale(1);
    }
    /* Responsive Design */
    @media (max-width: 576px) {
        .login-container {
            padding: 1.5rem;
            margin: 0 1rem;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Login Section -->
<section class="login-section animate-section" data-animate>
    <div class="container">
        <div class="login-container animate-form">
            <h2 class="h2 fw-bold text-center mb-4 animate-title typing-text text-gold">Login to <?php echo APP_NAME; ?></h2>
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <?php foreach ($errors as $error): ?>
                        <p class="mb-0"><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="mb-3">
                    <label for="email" class="form-label"><i class="fas fa-envelope me-2"></i>Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label"><i class="fas fa-lock me-2"></i>Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="d-grid mb-3">
                    <button type="submit" class="btn login-button">Login</button>
                </div>
                <p class="text-center text-light">
                    Don't have an account? <a href="<?php echo APP_URL; ?>/pages/auth/register.php" class="text-gold">Register</a>
                </p>
            </form>
        </div>
    </div>
</section>

<!-- Include footer -->
<?php include '../../includes/footer.php'; ?>

<!-- Scripts -->
<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });
        sections.forEach(section => observer.observe(section));
    });
</script>

<?php
if (isset($db)) {
    $db->closeConnection();
}
?>