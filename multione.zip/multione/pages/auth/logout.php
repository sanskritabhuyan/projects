<?php
// pages/auth/logout.php - MULTIONE Logout
require_once '../../includes/config.php';

// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Log session data before clearing (for debugging)
error_log("Logout - Session before clearing: " . print_r($_SESSION, true));

// Clear all session variables
$_SESSION = [];

// Destroy the session
if (session_destroy()) {
    error_log("Logout - Session successfully destroyed");
} else {
    error_log("Logout - Failed to destroy session");
}

// Clear session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Redirect to login page
$login_url = APP_URL . '/pages/auth/login.php';
error_log("Logout - Redirecting to: $login_url");
header('Location: ' . $login_url);
exit;
?>