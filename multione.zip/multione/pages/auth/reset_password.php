<?php
// reset_password.php - Password reset for MULTIONE
require_once '../../includes/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Reset Password';
include '../../includes/header.php';
?>

<!-- Reset Password Section -->
<section class="login-section py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="card glassmorphic p-4">
                    <h2 class="h3 fw-bold text-center mb-4 text-gold">Reset Password</h2>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="email" class="form-label text-light">Email</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Send Reset Link</button>
                        </div>
                        <div class="text-center mt-3">
                            <a href="login.php" class="text-gold">Back to Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../../includes/footer.php'; ?>