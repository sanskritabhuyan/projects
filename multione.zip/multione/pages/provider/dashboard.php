<?php
// pages/provider/dashboard.php - MULTIONE Service Provider Dashboard
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

// Error reporting configuration (disable display in production)
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL & ~E_DEPRECATED);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is a provider
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_provider']) || !$_SESSION['is_provider']) {
    error_log("Provider Dashboard - Unauthorized access, redirecting to login");
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

// Initialize database connection
$db = Database::getInstance();
$conn = $db->getConnection();

// Helper function for safe output
function safeOutput($value, $default = 'Not provided') {
    return isset($value) ? htmlspecialchars($value) : $default;
}

// Fetch provider details
$user_id = $_SESSION['user_id'];
$provider = null;
try {
    $stmt = $conn->prepare("
        SELECT u.full_name, u.username, u.email, u.phone, u.address, sp.provider_id
        FROM users u
        LEFT JOIN service_providers sp ON u.user_id = sp.user_id
        WHERE u.user_id = ?
    ");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $provider = $result->fetch_assoc();
    $stmt->close();
} catch (Exception $e) {
    error_log("Provider Dashboard - Error fetching provider: " . $e->getMessage());
}

// Fetch upcoming bookings
$bookings = [];
try {
    $stmt = $conn->prepare("
        SELECT b.booking_id, b.service_type, b.booking_date, b.status, u.full_name AS client_name
        FROM bookings b
        JOIN service_providers sp ON b.provider_id = sp.provider_id
        JOIN users u ON b.user_id = u.user_id
        WHERE sp.user_id = ? AND b.booking_date >= NOW()
        ORDER BY b.booking_date ASC
    ");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    $stmt->close();
} catch (Exception $e) {
    error_log("Provider Dashboard - Error fetching bookings: " . $e->getMessage());
}

// Set page title
$pageTitle = 'Service Provider Dashboard';

// Include header
include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    /* Dashboard Section */
    .dashboard-section {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: calc(100vh - 56px);
        padding: 2rem 0;
        color: #f3f4f6;
    }
    .dashboard-container {
        background: rgba(255, 255, 255, 0.05);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        max-width: 900px;
        margin: 0 auto;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease;
    }
    .dashboard-container:hover {
        transform: scale(1.02);
    }
    .card {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 10px;
        color: #f3f4f6;
        transition: transform 0.3s ease;
    }
    .card:hover {
        transform: scale(1.05);
    }
    .card-title {
        color: #facc15;
        font-weight: 600;
    }
    .text-gold {
        color: #facc15;
    }
    .btn-gold {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        transition: transform 0.3s ease, background 0.3s ease;
    }
    .btn-gold:hover {
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
        transform: scale(1.05);
    }
    .table {
        color: #f3f4f6;
    }
    .table th {
        color: #facc15;
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
    .table td {
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    /* Responsive Design */
    @media (max-width: 576px) {
        .dashboard-container {
            padding: 1.5rem;
            margin: 0 1rem;
        }
        .card {
            margin-bottom: 1rem;
        }
    }
</style>

<!-- Dashboard Section -->
<section class="dashboard-section">
    <div class="container">
        <div class="dashboard-container">
            <h2 class="h2 fw-bold text-center mb-4 text-gold">Welcome, <?php echo safeOutput($provider['full_name'] ?? $_SESSION['username']); ?>!</h2>
            
            <!-- Provider Information -->
            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="card-title">Provider Information</h3>
                    <?php if ($provider): ?>
                        <p><strong>Full Name:</strong> <?php echo safeOutput($provider['full_name']); ?></p>
                        <p><strong>Username:</strong> <?php echo safeOutput($provider['username']); ?></p>
                        <p><strong>Email:</strong> <?php echo safeOutput($provider['email']); ?></p>
                        <p><strong>Phone:</strong> <?php echo safeOutput($provider['phone']); ?></p>
                        <p><strong>Address:</strong> <?php echo safeOutput($provider['address']); ?></p>
                        <p><strong>Provider ID:</strong> <?php echo safeOutput($provider['provider_id']); ?></p>
                        <a href="<?php echo APP_URL; ?>/pages/provider/profile.php" class="btn btn-gold">Edit Profile</a>
                    <?php else: ?>
                        <p class="text-danger">Unable to load provider information.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Upcoming Bookings -->
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Upcoming Bookings</h3>
                    <?php if (!empty($bookings)): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Booking ID</th>
                                        <th>Client</th>
                                        <th>Service Type</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                        <tr>
                                            <td><?php echo safeOutput($booking['booking_id']); ?></td>
                                            <td><?php echo safeOutput($booking['client_name']); ?></td>
                                            <td><?php echo safeOutput($booking['service_type']); ?></td>
                                            <td><?php echo safeOutput(date('Y-m-d H:i', strtotime($booking['booking_date']))); ?></td>
                                            <td><?php echo safeOutput($booking['status']); ?></td>
                                            <td>
                                                <a href="<?php echo APP_URL; ?>/pages/provider/manage_bookings.php?booking_id=<?php echo $booking['booking_id']; ?>" 
                                                   class="btn btn-gold btn-sm">Manage</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p>No upcoming bookings found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Include footer -->
<?php include '../../includes/footer.php'; ?>

<!-- Scripts -->
<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>

<?php
// Close database connection
$db->closeConnection();
?>