<?php
// pages/provider/profile.php - Provider Profile Management
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'provider') {
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

$errors = [];
$success = '';
$full_name = $_SESSION['username'];
$email = '';
$service_type = '';
$location_lat = '';
$location_lng = '';
$availability_status = 0;

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $stmt = $conn->prepare("SELECT u.email, sp.service_type, sp.location_lat, sp.location_lng, sp.availability_status 
                            FROM users u 
                            JOIN service_providers sp ON u.user_id = sp.user_id 
                            WHERE u.user_id = ?");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $provider = $result->fetch_assoc();
    $email = $provider['email'];
    $service_type = $provider['service_type'];
    $location_lat = $provider['location_lat'];
    $location_lng = $provider['location_lng'];
    $availability_status = $provider['availability_status'];
    $stmt->close();
} catch (Exception $e) {
    error_log("Provider profile fetch error: " . $e->getMessage());
    $errors[] = 'Unable to load profile.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $service_type = trim($_POST['service_type'] ?? '');
    $location_lat = trim($_POST['location_lat'] ?? '');
    $location_lng = trim($_POST['location_lng'] ?? '');
    $availability_status = isset($_POST['availability_status']) ? 1 : 0;

    if (empty($full_name)) {
        $errors[] = 'Full name is required.';
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Valid email is required.';
    }
    if (!empty($password) && strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if (empty($service_type)) {
        $errors[] = 'Service type is required.';
    }
    if (!empty($location_lat) && !is_numeric($location_lat)) {
        $errors[] = 'Invalid latitude.';
    }
    if (!empty($location_lng) && !is_numeric($location_lng)) {
        $errors[] = 'Invalid longitude.';
    }

    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
            $stmt->bind_param('si', $email, $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $errors[] = 'Email is already in use.';
            }
            $stmt->close();

            if (empty($errors)) {
                $conn->begin_transaction();
                $query = "UPDATE users SET full_name = ?, email = ?";
                $params = [$full_name, $email];
                $types = 'ss';
                if (!empty($password)) {
                    $query .= ", password = ?";
                    $params[] = password_hash($password, PASSWORD_DEFAULT);
                    $types .= 's';
                }
                $query .= " WHERE user_id = ?";
                $params[] = $_SESSION['user_id'];
                $types .= 'i';
                $stmt = $conn->prepare($query);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("UPDATE service_providers SET service_type = ?, location_lat = ?, location_lng = ?, availability_status = ? 
                                        WHERE user_id = ?");
                $lat = $location_lat ? floatval($location_lat) : null;
                $lng = $location_lng ? floatval($location_lng) : null;
                $stmt->bind_param('sddii', $service_type, $lat, $lng, $availability_status, $_SESSION['user_id']);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                $_SESSION['username'] = $full_name;
                $success = 'Profile updated successfully.';
            }
        } catch (Exception $e) {
            $conn->rollback();
            error_log("Provider profile update error: " . $e->getMessage());
            $errors[] = 'An error occurred. Please try again.';
        }
    }
}

$pageTitle = 'Provider Profile';
include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    .profile-section {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: calc(100vh - 56px);
        padding: 3rem 0;
    }
    .profile-container {
        background: rgba(30, 41, 59, 0.3);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease;
    }
    .profile-container:hover {
        transform: scale(1.02);
    }
    .form-control {
        background: rgba(30, 41, 59, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #f3f4f6;
    }
    .form-control:focus {
        background: rgba(30, 41, 59, 0.7);
        border-color: #facc15;
        box-shadow: none;
    }
    .form-label {
        color: #facc15;
    }
    .btn-gold {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        transition: transform 0.3s ease, background 0.3s ease;
    }
    .btn-gold:hover {
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
        transform: scale(1.05);
    }
    .error-message, .success-message {
        background: rgba(254, 226, 226, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #facc15;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }
    .success-message {
        background: rgba(209, 250, 229, 0.2);
    }
    .text-gold {
        color: #facc15;
    }
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    @media (max-width: 576px) {
        .profile-container {
            padding: 1.5rem;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Profile Section -->
<section class="profile-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Provider Profile</h2>
        <div class="profile-container mx-auto" style="max-width: 500px;">
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <?php foreach ($errors as $error): ?>
                        <p class="mb-0"><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success-message">
                    <p class="mb-0"><?php echo htmlspecialchars($success); ?></p>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="mb-3">
                    <label for="full_name" class="form-label"><i class="fas fa-user me-2"></i>Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($full_name); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label"><i class="fas fa-envelope me-2"></i>Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label"><i class="fas fa-lock me-2"></i>New Password (optional)</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Leave blank to keep current">
                </div>
                <div class="mb-3">
                    <label for="service_type" class="form-label"><i class="fas fa-tools me-2"></i>Service Type</label>
                    <input type="text" class="form-control" id="service_type" name="service_type" value="<?php echo htmlspecialchars($service_type); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="location_lat" class="form-label"><i class="fas fa-map-marker-alt me-2"></i>Latitude (optional)</label>
                    <input type="text" class="form-control" id="location_lat" name="location_lat" value="<?php echo htmlspecialchars($location_lat); ?>">
                </div>
                <div class="mb-3">
                    <label for="location_lng" class="form-label"><i class="fas fa-map-marker-alt me-2"></i>Longitude (optional)</label>
                    <input type="text" class="form-control" id="location_lng" name="location_lng" value="<?php echo htmlspecialchars($location_lng); ?>">
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="availability_status" name="availability_status" <?php echo $availability_status ? 'checked' : ''; ?>>
                    <label class="form-check-label text-light" for="availability_status">Available for Bookings</label>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-gold">Update Profile</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php include '../../includes/footer.php'; ?>

<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });
        sections.forEach(section => observer.observe(section));
    });
</script>

<?php
if (isset($db)) {
    $db->closeConnection();
}
?>