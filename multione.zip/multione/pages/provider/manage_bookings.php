<?php
// pages/provider/manage_bookings.php - Provider Booking Management
require_once '../../includes/config.php';
require_once '../../includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'provider') {
    header('Location: ' . APP_URL . '/pages/auth/login.php');
    exit;
}

$errors = [];
$success = '';

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    $stmt = $conn->prepare("SELECT b.booking_id, u.full_name, b.service_type, b.booking_date, b.status 
                            FROM bookings b 
                            JOIN users u ON b.user_id = u.user_id 
                            JOIN service_providers sp ON b.provider_id = sp.provider_id 
                            WHERE sp.user_id = ? 
                            ORDER BY b.created_at DESC");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} catch (Exception $e) {
    error_log("Manage bookings error: " . $e->getMessage());
    $errors[] = 'Unable to load bookings.';
    $bookings = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['status'])) {
    $booking_id = intval($_POST['booking_id']);
    $status = trim($_POST['status']);

    if (!in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'])) {
        $errors[] = 'Invalid status.';
    } else {
        try {
            $stmt = $conn->prepare("UPDATE bookings b 
                                    JOIN service_providers sp ON b.provider_id = sp.provider_id 
                                    SET b.status = ? 
                                    WHERE b.booking_id = ? AND sp.user_id = ?");
            $stmt->bind_param('sii', $status, $booking_id, $_SESSION['user_id']);
            $stmt->execute();
            if ($stmt->affected_rows > 0) {
                $success = 'Booking status updated.';
                header('Location: ' . APP_URL . '/pages/provider/manage_bookings.php');
                exit;
            } else {
                $errors[] = 'No booking found or unauthorized.';
            }
            $stmt->close();
        } catch (Exception $e) {
            error_log("Booking status update error: " . $e->getMessage());
            $errors[] = 'An error occurred. Please try again.';
        }
    }
}

$pageTitle = 'Manage Bookings';
include '../../includes/header.php';
?>

<!-- Custom CSS -->
<style>
    .bookings-section {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: calc(100vh - 56px);
        padding: 3rem 0;
    }
    .bookings-container {
        background: rgba(30, 41, 59, 0.3);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        padding: 2rem;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease;
    }
    .bookings-container:hover {
        transform: scale(1.02);
    }
    .table {
        background: rgba(30, 41, 59, 0.5);
        color: #f3f4f6;
    }
    .table th, .table td {
        border-color: rgba(255, 255, 255, 0.1);
    }
    .form-select {
        background: rgba(30, 41, 59, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #f3f4f6;
    }
    .form-select:focus {
        background: rgba(30, 41, 59, 0.7);
        border-color: #facc15;
        box-shadow: none;
    }
    .btn-gold {
        background: rgba(250, 204, 21, 0.2);
        border: 1px solid #facc15;
        color: #facc15;
        transition: transform 0.3s ease, background 0.3s ease;
    }
    .btn-gold:hover {
        background: rgba(250, 204, 21, 0.4);
        color: #fff;
        transform: scale(1.05);
    }
    .error-message, .success-message {
        background: rgba(254, 226, 226, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #facc15;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1.5rem;
    }
    .success-message {
        background: rgba(209, 250, 229, 0.2);
    }
    .text-gold {
        color: #facc15;
    }
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    @media (max-width: 576px) {
        .bookings-container {
            padding: 1.5rem;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Bookings Section -->
<section class="bookings-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Manage Your Bookings</h2>
        <div class="bookings-container">
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <?php foreach ($errors as $error): ?>
                        <p class="mb-0"><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="success-message">
                    <p class="mb-0"><?php echo htmlspecialchars($success); ?></p>
                </div>
            <?php endif; ?>
            <?php if (empty($bookings)): ?>
                <p class="text-light">No bookings yet.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Client</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $booking): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($booking['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                    <td><?php echo htmlspecialchars(date('Y-m-d H:i', strtotime($booking['booking_date']))); ?></td>
                                    <td><?php echo htmlspecialchars(ucfirst($booking['status'])); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking['booking_id']; ?>">
                                            <select name="status" class="form-select form-select-sm mb-2">
                                                <option value="pending" <?php echo $booking['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="confirmed" <?php echo $booking['status'] === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                                <option value="completed" <?php echo $booking['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                                <option value="cancelled" <?php echo $booking['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                            </select>
                                            <button type="submit" class="btn btn-gold btn-sm">Update</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php include '../../includes/footer.php'; ?>

<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, { threshold: 0.1 });
        sections.forEach(section => observer.observe(section));
    });
</script>

<?php
if (isset($db)) {
    $db->closeConnection();
}
?>