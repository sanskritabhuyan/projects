<?php
// config.php - MULTIONE Configuration

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
session_start();

// Define constants
define('APP_NAME', 'MULTIONE');
define('APP_URL', 'http://localhost/multione');
define('ASSETS_PATH', APP_URL . '/assets');

// Database configuration (optional, if needed)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'multione');

// Ensure no output before this point
?>