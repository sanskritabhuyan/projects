<?php
// header.php - MULTIONE Header

// Enable error reporting (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if APP_NAME is defined
if (!defined('APP_NAME')) {
    die('Access denied: APP_NAME not defined');
}

// Debug: Verify constants (uncomment for debugging)
// error_log("ASSETS_PATH: " . ASSETS_PATH);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle ?? 'MULTIONE'); ?></title>
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo ASSETS_PATH; ?>/css/leaflet.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        /* Navbar Styling */
        .navbar {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
            position: sticky;
            top: 0;
            z-index: 1000;
            padding: 1rem 0;
            transition: background 0.3s ease;
        }

        /* Navbar Brand (Logo) */
        .navbar-brand {
            display: flex;
            align-items: center;
        }
        .navbar-brand img {
            height: 40px;
            transition: transform 0.3s ease;
        }
        .navbar-brand img:hover {
            transform: rotate(20deg) scale(1.1);
        }
        .navbar-brand span {
            color: #facc15;
            font-weight: 700;
            font-size: 1.5rem;
            margin-left: 0.5rem;
        }

        /* Nav Links */
        .nav-link {
            color: #f3f4f6 !important;
            font-weight: 500;
            font-size: 1.1rem;
            padding: 0.5rem 1rem !important;
            position: relative;
            transition: color 0.3s ease;
        }
        .nav-link:hover {
            color: #facc15 !important;
        }
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: #facc15;
            transition: width 0.3s ease;
        }
        .nav-link:hover::after {
            width: 100%;
        }

        /* Logout Button */
        .logout-btn {
            background: rgba(250, 204, 21, 0.2);
            border: 1px solid #facc15;
            color: #facc15;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: transform 0.3s ease, background 0.3s ease, color 0.3s ease;
        }
        .logout-btn:hover {
            background: rgba(250, 204, 21, 0.4);
            color: #fff;
            transform: scale(1.05);
        }

        /* Dropdown Menu */
        .dropdown-menu {
            background: rgba(30, 41, 59, 0.3);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            margin-top: 0.5rem;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }
        .dropdown-item {
            color: #f3f4f6;
            font-weight: 500;
            padding: 0.5rem 1.5rem;
            transition: background 0.3s ease, color 0.3s ease;
        }
        .dropdown-item:hover {
            background: rgba(250, 204, 21, 0.2);
            color: #facc15;
        }
        .dropdown-divider {
            border-color: rgba(255, 255, 255, 0.2);
        }

        /* Toggler Icon */
        .navbar-toggler {
            border: none;
            color: #facc15;
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(250, 204, 21, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* Responsive Design */
        @media (max-width: 991px) {
            .navbar-nav {
                background: rgba(15, 23, 42, 0.9);
                border-radius: 10px;
                padding: 1rem;
                margin-top: 0.5rem;
            }
            .nav-link, .logout-btn {
                padding: 0.75rem 1rem !important;
            }
            .dropdown-menu {
                background: rgba(30, 41, 59, 0.5);
                border: none;
            }
        }
        @media (max-width: 576px) {
            .navbar-brand span {
                font-size: 1.2rem;
            }
            .navbar-brand img {
                height: 35px;
            }
            .logout-btn {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo APP_URL; ?>/index.php">
                <span><?php echo APP_NAME; ?></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo APP_URL; ?>/pages/map/locate_providers.php">Find Providers</a>
                    </li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="userDropdown" role="button" 
                               data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($_SESSION['username'] ?? 'Profile'); ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userDropdown">
                                <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/admin/dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/admin/manage_users.php"><i class="fas fa-users me-2"></i> Manage Users</a></li>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/admin/manage_providers.php"><i class="fas fa-tools me-2"></i> Manage Providers</a></li>
                                <?php elseif (isset($_SESSION['is_provider']) && $_SESSION['is_provider']): ?>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/provider/dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/provider/profile.php"><i class="fas fa-user me-2"></i> Profile</a></li>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/provider/manage_bookings.php"><i class="fas fa-tasks me-2"></i> Manage Bookings</a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/user/dashboard.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/user/profile.php"><i class="fas fa-user me-2"></i> Profile</a></li>
                                    <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/user/booking.php"><i class="fas fa-calendar-check me-2"></i> Bookings</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="<?php echo APP_URL; ?>/pages/auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="logout-btn" href="<?php echo APP_URL; ?>/pages/auth/logout.php"><i class="fas fa-sign-out-alt me-1"></i> Logout</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo APP_URL; ?>/pages/auth/login.php"><i class="fas fa-sign-in-alt me-1"></i> Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo APP_URL; ?>/pages/auth/register.php"><i class="fas fa-user-plus me-1"></i> Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Bootstrap JS -->
    <script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
</body>
</html>