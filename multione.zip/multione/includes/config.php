<?php
// config.php - Configuration settings for MULTIONE project

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Default XAMPP MySQL user
define('DB_PASS', '');      // Default XAMPP MySQL password (empty)
define('DB_NAME', 'multione');

// Application settings
define('APP_NAME', 'MULTIONE');
define('APP_URL', 'http://localhost/multione'); // Adjust if using a different port or folder
define('MAP_API_KEY', ''); // Add free map API key (e.g., OpenStreetMap or Google Maps free tier)

// Security settings
define('SESSION_TIMEOUT', 1800); // Session timeout in seconds (30 minutes)
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);

// Error reporting (set to FALSE in production)
define('DEBUG_MODE', TRUE);

// File paths
define('ASSETS_PATH', APP_URL . '/assets');
define('UPLOADS_PATH', __DIR__ . '/uploads'); // Adjust if adding file uploads later

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
?>