<?php
// footer.php - MULTIONE Footer
if (!defined('APP_NAME')) {
    die('Access denied');
}
?>
<footer class="text-white py-4" style="background: #0f172a;">
    <div class="container">
        <div class="row">
            <!-- Branding -->
            <div class="col-md-4 mb-3">
                <h5 class="fw-bold"><?php echo APP_NAME; ?></h5>
                <p style="color: #94a3b8;">Your trusted platform for home services.</p>
            </div>
            <!-- Links -->
            <div class="col-md-4 mb-3">
                <h5 class="fw-bold">Explore</h5>
                <ul class="list-unstyled">
                    <li><a href="<?php echo APP_URL; ?>/index.php" class="text-white text-decoration-none">Home</a></li>
                    <li><a href="<?php echo APP_URL; ?>/pages/map/locate_providers.php" class="text-white text-decoration-none">Find Providers</a></li>
                    <li><a href="<?php echo APP_URL; ?>/pages/auth/register.php" class="text-white text-decoration-none">Join Us</a></li>
                </ul>
            </div>
            <!-- Contact -->
            <div class="col-md-4 mb-3">
                <h5 class="fw-bold">Contact</h5>
                <p style="color: #94a3b8;">
                    Email: support@<?php echo strtolower(APP_NAME); ?>.com<br>
                    Phone: +91-123-456-7890
                </p>
            </div>
        </div>
        <hr style="background: #1e293b;">
        <div class="text-center">
            <p class="mb-0" style="color: #94a3b8;">© <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
        </div>
    </div>
</footer>
<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
</body>
</html>