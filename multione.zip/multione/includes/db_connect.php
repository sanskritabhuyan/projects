<?php
// db_connect.php - Database connection for MULTIONE project

require_once __DIR__ . '/config.php';

class Database {
    private $conn;
    private static $instance = null;

    // Private constructor for Singleton pattern
    private function __construct() {
        try {
            $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
            if ($this->conn->connect_error) {
                throw new Exception("Connection failed: " . $this->conn->connect_error);
            }
            
            // Set charset to UTF-8
            $this->conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            if (DEBUG_MODE) {
                die("Database connection error: " . $e->getMessage());
            } else {
                die("Unable to connect to the database. Please try again later.");
            }
        }
    }

    // Get instance of Database (Singleton)
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // Get database connection
    public function getConnection() {
        return $this->conn;
    }

    // Close connection
    public function closeConnection() {
        if ($this->conn) {
            $this->conn->close();
            $this->conn = null;
            self::$instance = null;
        }
    }

    // Prevent cloning
    private function __clone() {}

    // Prevent unserialization (must be public)
    public function __wakeup() {}
}
?>