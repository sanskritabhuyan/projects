<?php
// api/providers.php - API to fetch service providers for MULTIONE
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/db_connect.php';

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT sp.provider_id, sp.service_type, sp.location_lat, sp.location_lng, u.full_name 
                            FROM service_providers sp 
                            JOIN users u ON sp.user_id = u.user_id 
                            WHERE sp.availability_status = 1 
                            AND sp.location_lat IS NOT NULL 
                            AND sp.location_lng IS NOT NULL");
    $stmt->execute();
    $result = $stmt->get_result();
    
    $providers = [];
    while ($row = $result->fetch_assoc()) {
        $providers[] = [
            'provider_id' => $row['provider_id'],
            'full_name' => $row['full_name'],
            'service_type' => $row['service_type'],
            'location_lat' => floatval($row['location_lat']),
            'location_lng' => floatval($row['location_lng'])
        ];
    }
    
    $stmt->close();
    echo json_encode($providers);
} catch (Exception $e) {
    error_log("API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Unable to fetch providers']);
} finally {
    if (isset($db)) {
        $db->closeConnection();
    }
}
?>