<?php
// index.php - MULTIONE Web Application Entry Point
require_once 'includes/config.php';
require_once 'includes/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check login status
$isLoggedIn = isset($_SESSION['user_id']);
$userType = isset($_SESSION['user_type']) ? $_SESSION['user_type'] : null;

// Set page title
$pageTitle = 'Home';

// Include header
include 'includes/header.php';
?>

<!-- Custom CSS -->
<style>
    /* Hero Section */
    .hero-section {
        background: linear-gradient(135deg, #1e3a8a, #60a5fa);
        color: white;
        padding: 5rem 0;
        text-align: center;
    }
    .hero-button {
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        padding: 0.75rem 2rem;
        font-weight: 500;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .hero-button:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        background: rgba(250, 204, 21, 0.2);
        color: #facc15;
    }

    /* Services Section */
    .services-section {
        background: #0f172a;
        padding: 4rem 0;
    }
    .service-card {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .service-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
    }
    .service-icon {
        font-size: 2.5rem;
        margin-bottom: 1rem;
        transition: transform 0.3s ease;
    }
    .service-card:hover .service-icon {
        transform: scale(1.2);
        color: #facc15;
    }

    /* Map Section */
    .map-section {
        background: #0f172a;
        padding: 4rem 0;
    }
    .map-container {
        height: 400px;
        width: 100%;
        background: rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        position: relative;
        z-index: 1;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .map-container:hover {
        transform: scale(1.01);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
    }
    .map-container .leaflet-container {
        background: transparent;
    }
    .custom-marker {
        font-size: 20px;
        color: #facc15;
    }
    .marker-pin {
        color: #facc15;
        font-size: 24px;
        text-align: center;
    }
    .error-message {
        background: rgba(254, 226, 226, 0.2);
        padding: 1.5rem;
        border-radius: 8px;
        text-align: center;
        margin-bottom: 2rem;
        color: #f3f4f6;
    }

    /* Text Colors */
    .text-gold {
        color: #facc15;
    }

    /* Typing Animation */
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid #facc15;
        animation: typing 3s steps(40, end) forwards, blink-caret 0.75s step-end infinite;
    }
    @keyframes typing {
        from { width: 0; }
        to { width: 100%; }
    }
    @keyframes blink-caret {
        from, to { border-color: transparent; }
        50% { border-color: #facc15; }
    }

    /* Animation Classes */
    .animate-section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-title {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-title {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-text {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.8s ease, transform 0.8s ease 0.4s;
    }
    .animate-section.visible .animate-text {
        opacity: 1;
        transform: translateY(0);
    }
    .animate-button {
        opacity: 0;
        transform: scale(0.9);
        transition: opacity 0.8s ease, transform 0.8s ease 0.6s;
    }
    .animate-section.visible .animate-button {
        opacity: 1;
        transform: scale(1);
    }
    .animate-card {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-section.visible .animate-card:nth-child(1) {
        opacity: 1;
        transform: translateY(0);
        transition-delay: 0.2s;
    }
    .animate-section.visible .animate-card:nth-child(2) {
        opacity: 1;
        transform: translateY(0);
        transition-delay: 0.4s;
    }
    .animate-section.visible .animate-card:nth-child(3) {
        opacity: 1;
        transform: translateY(0);
        transition-delay: 0.6s;
    }
    .animate-map {
        opacity: 0;
        transform: scale(0.95);
        transition: opacity 0.8s ease, transform 0.8s ease 0.2s;
    }
    .animate-section.visible .animate-map {
        opacity: 1;
        transform: scale(1);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .hero-section {
            padding: 3rem 0;
        }
        .hero-section h1 {
            font-size: 2.5rem;
        }
        .map-container {
            height: 300px;
        }
        .services-section, .map-section {
            padding: 2rem 0;
        }
        .typing-text {
            animation: typing 2s steps(30, end) forwards, blink-caret 0.75s step-end infinite;
        }
    }
</style>

<!-- Hero Section -->
<section class="hero-section text-white py-5 animate-section" data-animate>
    <div class="container text-center">
        <h1 class="display-3 fw-bold mb-4 animate-title typing-text">Welcome to <?php echo APP_NAME; ?></h1>
        <p class="lead mb-5 animate-text">Premium home services at your fingertips.</p>
        <a href="<?php echo $isLoggedIn ? 'pages/user/booking.php' : 'pages/auth/register.php'; ?>" 
           class="btn btn-primary btn-lg animate-button hero-button">
            <i class="fas fa-concierge-bell me-2"></i> <?php echo $isLoggedIn ? 'Book Now' : 'Join Today'; ?>
        </a>
    </div>
</section>

<!-- Services Section -->
<section class="py-5 services-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Our Elite Services</h2>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <!-- Electrician -->
            <div class="col">
                <div class="card service-card glassmorphic h-100 text-center border-0 animate-card">
                    <i class="fas fa-bolt service-icon text-gold mt-4"></i>
                    <div class="card-body">
                        <h3 class="card-title h4 fw-bold text-light">Electrician</h3>
                        <p class="card-text text-light">Sophisticated electrical solutions.</p>
                    </div>
                </div>
            </div>
            <!-- Plumber -->
            <div class="col">
                <div class="card service-card glassmorphic h-100 text-center border-0 animate-card">
                    <i class="fas fa-faucet service-icon text-gold mt-4"></i>
                    <div class="card-body">
                        <h3 class="card-title h4 fw-bold text-light">Plumber</h3>
                        <p class="card-text text-light">Precision plumbing services.</p>
                    </div>
                </div>
            </div>
            <!-- Carpenter -->
            <div class="col">
                <div class="card service-card glassmorphic h-100 text-center border-0 animate-card">
                    <i class="fas fa-hammer service-icon text-gold mt-4"></i>
                    <div class="card-body">
                        <h3 class="card-title h4 fw-bold text-light">Carpenter</h3>
                        <p class="card-text text-light">Exquisite woodworking craftsmanship.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="py-5 map-section animate-section" data-animate>
    <div class="container">
        <h2 class="h2 fw-bold text-center mb-5 animate-title typing-text text-gold">Find Top Providers</h2>
        <div id="map-error" class="error-message" style="display: none;"></div>
        <div id="map" class="map-container glassmorphic animate-map"></div>
    </div>
</section>

<!-- Include footer -->
<?php include 'includes/footer.php'; ?>

<!-- Scripts -->
<script src="<?php echo ASSETS_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo ASSETS_PATH; ?>/js/leaflet.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Animation Script
        const sections = document.querySelectorAll('.animate-section');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    if (entry.target.classList.contains('map-section')) {
                        initializeMap();
                    }
                }
            });
        }, { threshold: 0.1 });

        sections.forEach(section => observer.observe(section));

        // Map Initialization Function
        function initializeMap() {
            try {
                const mapContainer = document.getElementById('map');
                const errorDiv = document.getElementById('map-error');
                if (!mapContainer) {
                    console.error('Map container not found');
                    errorDiv.textContent = 'Map container not found';
                    errorDiv.style.display = 'block';
                    return;
                }

                const map = L.map('map', {
                    center: [26.1445, 91.7362], // Guwahati, Assam
                    zoom: 13,
                    scrollWheelZoom: false
                });

                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                    maxZoom: 18
                }).addTo(map);

                const customIcon = L.divIcon({
                    className: 'custom-marker',
                    html: '<div class="marker-pin"><i class="fas fa-map-pin"></i></div>',
                    iconSize: [40, 40],
                    iconAnchor: [20, 40],
                    popupAnchor: [0, -40]
                });

                fetch('<?php echo APP_URL; ?>/api/providers.php')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (!Array.isArray(data) || data.length === 0) {
                            errorDiv.textContent = 'No providers available at the moment.';
                            errorDiv.style.display = 'block';
                            L.marker([26.1445, 91.7362], { icon: customIcon })
                                .addTo(map)
                                .bindPopup('Default Location: Guwahati');
                            return;
                        }

                        const bounds = [];
                        data.forEach(provider => {
                            if (provider.location_lat && provider.location_lng && !isNaN(provider.location_lat) && !isNaN(provider.location_lng)) {
                                const latLng = [provider.location_lat, provider.location_lng];
                                bounds.push(latLng);
                                L.marker(latLng, { icon: customIcon })
                                    .addTo(map)
                                    .bindPopup(`
                                        <strong>${provider.full_name}</strong><br>
                                        Service: ${provider.service_type.charAt(0).toUpperCase() + provider.service_type.slice(1)}
                                    `)
                                    .on('mouseover', function() { this.openPopup(); })
                                    .on('mouseout', function() { this.closePopup(); });
                            } else {
                                console.warn('Invalid coordinates for provider:', provider);
                            }
                        });

                        if (bounds.length > 0) {
                            map.fitBounds(bounds, { padding: [50, 50] });
                        } else {
                            console.warn('No valid provider coordinates found');
                            L.marker([26.1445, 91.7362], { icon: customIcon })
                                .addTo(map)
                                .bindPopup('Default Location: Guwahati');
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching providers:', error);
                        errorDiv.textContent = 'Unable to load providers. Please try again later.';
                        errorDiv.style.display = 'block';
                        L.marker([26.1445, 91.7362], { icon: customIcon })
                            .addTo(map)
                            .bindPopup('Default Location: Guwahati');
                    });

                setTimeout(() => {
                    map.invalidateSize();
                }, 500);
                window.addEventListener('resize', () => map.invalidateSize());
            } catch (e) {
                console.error('Map initialization failed:', e);
                document.getElementById('map-error').textContent = 'Failed to initialize map.';
                document.getElementById('map-error').style.display = 'block';
            }
        }
    });
</script>

<?php
// Close database connection
if (isset($db)) {
    $db->closeConnection();
}
?>