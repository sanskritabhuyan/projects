<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My HTML FORM </title>
</head>
<body>
    <form method="post" action="insert.php">
        <label> First_name: </label>
        <input type="First_name" name="First_name">
        <label> Last_name: </label>
        <input type="Last_name" name="Last_name"><br><br>
        <label>Date_of_Birth: </label>
        <input type="date" name="Date_of_Birth"><br><br>
        <label>Nationality: </label>
        <input type="Nationality" name="Nationality"><br><br>
        <label>Email: </label>
        <input type="email" name="Email"><br><br>
        <label>Address: </label>
        <input type="Address" name="Address"><br><br>
        <input type="submit" name="submit">
    </form>
</body>
</html>