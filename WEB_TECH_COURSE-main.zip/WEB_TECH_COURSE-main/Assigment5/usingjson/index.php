<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Insert Student Data ( using JSON) </h1>
    <form action="save_json.php" method="post">
        <input type="text" name="id" id="id" placeholder="Enter your id">
        <br>
        <input type="text" name="name" id="name" placeholder="Enter your name">
        <br>
        <input type="text" name="department" id="department" placeholder="Enter your department">
        <br>
        <button type="submit">Submit</button> 
    </form>
</body>
</html>