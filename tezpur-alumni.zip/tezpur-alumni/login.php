<?php
require_once "config/database.php"; 
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role']; 

    try {
        $db = new Database();
        $conn = $db->getConnection();

        $query = "SELECT * FROM users WHERE email = :email AND role = :role";
        $stmt = $conn->prepare($query);
        $stmt->execute([':email' => $email, ':role' => $role]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];

            header("Location: dashboard.php");
            exit;
        } else {
            $message = "Invalid credentials!";
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Tezpur University Alumni</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            background: url('images/background4.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            margin: 0;
        }
        .container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            width: 350px;
            max-width: 90%;
        }
        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: black;
        }
        input, select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            font-size: 18px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 12px;
            font-size: 18px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        p {
            margin-top: 10px;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .home-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: black;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .home-button:hover {
            background: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h2>Login</h2>
            <?php if (!empty($message)) echo "<p>$message</p>"; ?>
            <form method="POST">
                <select name="role">
                    <option value="alumni">Alumni</option>
                    <option value="admin">Admin</option>
                </select>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
                <p><a href="forgot_password.php">Forgot Password?</a></p>
            </form>
        </div>
        <a href="index.php" class="home-button">🏠 Home</a>
    </div>
</body>
</html>
