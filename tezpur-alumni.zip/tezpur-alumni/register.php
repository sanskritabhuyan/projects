<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        /* Background Styling */
        body {
            background: url('images/background4.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Register Box */
        .register-box {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            width: 80%; /* Increased width */
            max-width: 1000px; /* Wider max width */
            text-align: center;
        }

        h2 {
            font-size: 22px;
            margin-bottom: 15px;
            color: black;
        }

        .form-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .form-group {
            width: 48%; /* Two inputs per row */
            margin-bottom: 10px;
        }

        input, select {
            width: 100%;
            padding: 8px;
            font-size: 14px;
            border: 1px solid #000;
            border-radius: 5px;
            color: black;
            background: white;
        }

        input::placeholder {
            color: black;
        }

        /* Full-width fields */
        .full-width {
            width: 100%;
        }

        /* Radio Buttons */
        .radio-group {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 10px 0;
            color: black;
        }

        label {
            font-size: 14px;
            color: black;
        }

        button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #0056b3;
        }

        /* Home Button */
        .home-button {
            padding: 10px 15px;
            background: black;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            display: inline-block;
            margin-top: 10px;
        }

        .home-button:hover {
            background: #333;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .register-box {
                width: 90%;
            }
            .form-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>

    <div class="register-box">
        <h2>Register</h2>
        <form action="register_process.php" method="POST" enctype="multipart/form-data">
            <div class="form-container">
                <div class="form-group"><input type="text" name="name" placeholder="Full Name" required></div>
                <div class="form-group"><input type="text" name="roll_no" placeholder="Roll Number" required></div>
                <div class="form-group"><input type="email" name="email" placeholder="Email" required></div>
                <div class="form-group"><input type="password" name="password" placeholder="Password" required></div>
                <div class="form-group"><input type="tel" name="phone" placeholder="Phone Number" required></div>

                <label class="full-width">Current Position:</label>
                <div class="radio-group full-width">
                    <label><input type="radio" name="position" value="Student" required> Student</label>
                    <label><input type="radio" name="position" value="Employee"> Employee</label>
                </div>

                <div class="form-group"><input type="text" name="company" placeholder="Company/Institute Name"></div>
                <div class="form-group"><input type="text" name="batch" placeholder="Batch (e.g., 2019-2023)" required></div>
                <div class="form-group"><input type="text" name="degree" placeholder="Degree (e.g., B.Tech, M.Tech)" required></div>
                <div class="form-group"><input type="text" name="branch" placeholder="Branch (e.g., CSE, ECE)" required></div>
                <div class="form-group"><input type="text" name="department" placeholder="Department" required></div>

                <div class="form-group full-width"><input type="text" name="home_address" placeholder="Home Address" required></div>

                <label class="full-width">Upload Profile Picture:</label>
                <div class="form-group full-width"><input type="file" name="profile_pic" accept="image/*" required></div>
            </div>

            <button type="submit">Register</button>
        </form>

        <a href="index.php" class="home-button">🏠 Home</a>
    </div>

</body>
</html>
