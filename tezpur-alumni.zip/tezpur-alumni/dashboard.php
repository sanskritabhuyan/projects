<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['name']; ?>!</h2>
    <p>You are logged in as <strong><?php echo $_SESSION['role']; ?></strong>.</p>

    <?php if ($_SESSION['role'] == 'admin'): ?>
        <a href="manage_users.php">Manage Users</a>
    <?php endif; ?>

    <a href="logout.php">Logout</a>
    <a href="index.php" class="home-button">🏠 Home</a>

</body>
</html>
