<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tezpur University Alumni Portal</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/slideshow.js" defer></script>
    <script>
        // Smooth scrolling for Home button
        function scrollToSection() {
            document.getElementById("tezpur-info").scrollIntoView({ behavior: "smooth" });
        }
    </script>
</head>
<body>

    <!-- Header with Slideshow -->
    <header>
        <h1>TEZPUR UNIVERSITY ALUMNI PORTAL</h1>
        <div class="slideshow-container">
            <div class="slide fade">
                <img src="images/background7.jpg" alt="Slide 1">
            </div>
            <div class="slide fade">
                <img src="images/background8.jpg" alt="Slide 2">
            </div>
            <div class="slide fade">
                <img src="images/background9.jpg" alt="Slide 3">
            </div>
        </div>
        <div class="dots">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav>
        <ul>
            <li><a href="#" onclick="scrollToSection()">Home</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="notice.php">Notice</a></li>
            <li><a href="login.php">Log In</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="donation.php">Donation</a></li>
            <li><a href="search_alumni.php">Search Alumni</a></li>
        </ul>
    </nav>

    <!-- Tezpur University Section -->
    <section id="tezpur-info" style="text-align: center; padding: 50px;">
        <h2>About Tezpur University</h2>
        <p>
            Tezpur University is a prestigious institution known for its excellence in education and research.
            It provides a platform for students to innovate, learn, and grow in various fields.
        </p>
    </section>

</body>
</html>
