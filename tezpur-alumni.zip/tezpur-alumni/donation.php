<?php
include('config/database.php'); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate</title>
    <style>
        body {
            background: url('images/background10.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            color: black;
            text-align: center;
            padding: 20px;
        }

        h2 {
            color: black;
        }

        form {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            display: inline-block;
            text-align: left;
        }

        input, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid black;
            border-radius: 5px;
        }

        button {
            background: black;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: gray;
        }

        /* Home Button */
        .home-button {
            display: block;
            width: 150px;
            margin: 30px auto 0;
            padding: 10px;
            background: black;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            text-align: center;
        }

        .home-button:hover {
            background: gray;
        }
    </style>
</head>
<body>

    <h2>Make a Donation</h2>
    <form action="process_donation.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" required>

        <label for="roll_no">Roll Number:</label>
        <input type="text" name="roll_no" required>

        <label for="amount">Amount (₹):</label>
        <input type="number" name="amount" required>

        <button type="submit">Donate</button>
    </form>

    <!-- Home Button at Bottom Center -->
    <a href="index.php" class="home-button">Home</a>

</body>
</html>
