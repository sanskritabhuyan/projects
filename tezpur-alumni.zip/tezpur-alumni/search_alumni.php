<?php
include('config/database.php'); 

$database = new Database();
$conn = $database->getConnection();

$results = [];
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $roll_no = trim($_POST['roll_no']);
    $department = trim($_POST['department']);

    // Validate roll number based on department
    $patterns = [
        'Computer Science' => '/^CSB\d{5}$/i',
        'Mechanical' => '/^MEB\d{5}$/i',
        'Electrical' => '/^ECB\d{5}$/i',
        'Civil' => '/^CEB\d{5}$/i'
    ];

    if (!empty($roll_no) && isset($patterns[$department])) {
        if (!preg_match($patterns[$department], $roll_no)) {
            $error = "Invalid Roll Number for $department department.";
        }
    }

    if (empty($error)) {
        // Query to search alumni
        $query = "SELECT * FROM search_alumni WHERE (name LIKE :name OR roll_no = :roll_no) AND department LIKE :department";
        $stmt = $conn->prepare($query);
        $stmt->bindValue(':name', "%$name%", PDO::PARAM_STR);
        $stmt->bindValue(':roll_no', $roll_no, PDO::PARAM_STR);
        $stmt->bindValue(':department', "%$department%", PDO::PARAM_STR);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Alumni</title>
    <style>
        body {
            background-color: black;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        .form-container {
            margin-top: 50px;
            display: inline-block;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }
        button {
            background: white;
            color: black;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background: gray;
        }
        .error {
            color: red;
            margin-top: 10px;
        }
        .result-container {
            margin-top: 20px;
            text-align: left;
            display: inline-block;
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid white;
            text-align: center;
        }
    </style>
</head>
<body>

<h2>Search Alumni</h2>

<div class="form-container">
    <form method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name">

        <label for="roll_no">Roll Number:</label>
        <input type="text" name="roll_no" placeholder="Format: CSB22076">

        <label for="department">Department:</label>
        <select name="department" required>
            <option value="">Select Department</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Mechanical">Mechanical</option>
            <option value="Electrical">Electrical</option>
            <option value="Civil">Civil</option>
        </select>

        <button type="submit">Search</button>
    </form>
</div>

<?php if (!empty($error)): ?>
    <p class="error"><?php echo $error; ?></p>
<?php endif; ?>

<?php if (!empty($results)): ?>
    <div class="result-container">
        <h3>Search Results</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Roll Number</th>
                <th>Department</th>
            </tr>
            <?php foreach ($results as $alumni): ?>
                <tr>
                    <td><?php echo htmlspecialchars($alumni['name']); ?></td>
                    <td><?php echo htmlspecialchars($alumni['roll_no']); ?></td>
                    <td><?php echo htmlspecialchars($alumni['department']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
<?php endif; ?>

<!-- Home Button -->
<a href="index.php" class="home-button">Home</a>


</body>
</html>
