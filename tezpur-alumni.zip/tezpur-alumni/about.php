<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="css/style.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Tezpur University Alumni</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background: url('images/background3.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
        }
        header {
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 20px;
            font-size: 24px;
        }
        section {
            padding: 20px;
            background: rgba(0, 0, 0, 0.6);
            margin: 20px auto;
            width: 50%;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<header>About Us</header>

<section>
    <h2>Welcome to Tezpur University Alumni Portal</h2>
    <p>This platform connects alumni from different batches, helping them stay informed about university events and activities.</p>
    <p>Join us and be part of the legacy!</p>
</section>
<a href="index.php" class="home-button">Home</a>

</body>
</html>
