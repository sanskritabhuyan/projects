<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notices - Tezpur University Alumni</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            color: white;
            text-align: center;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
        }
        
        /* Background Image */
        .background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('images/background5.jpg') no-repeat center center fixed;
            background-size: cover;
            filter: brightness(50%);
            z-index: -1;
        }

        /* Notice Box */
        .notice-container {
            background: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
            width: 60%;
        }

        /* White Heading */
        .notice-container h2 {
            font-size: 28px;
            color: white; /* Heading color changed to white */
        }

        p {
            font-size: 20px;
        }

        /* Home Button */
        .home-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: black;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            text-align: center;
        }

        .home-button:hover {
            background: gray;
        }
    </style>
</head>
<body>
    <!-- Faded Background -->
    <div class="background"></div>

    <!-- Notice Content -->
    <div class="notice-container">
        <h2>Upcoming Events</h2>  <!-- Heading now in White -->
        <p>Alumni Meetup for Session 2020-2024 will be held on <strong>24th March</strong>.</p>
        <p>Further notices will be updated here.</p>
    </div>

    <!-- Home Button Below Notice -->
    <a href="index.php" class="home-button">🏠 Home</a>
</body>
</html>
